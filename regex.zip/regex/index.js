let text = `
My favorite color is gray. HEX colorrrr code is     #808080. I believe you are not "Color blind"!
If you are not colour blind then tell me what is your favourite Colorr?

Or You like multiple colors?

Can we make the 'r'  is silent Like colo! REGULAR EXPRESSION makes me forget all spellings he he! 

`;

let text1 = "abcdefgh"
 


let result = text.match(/colou?r{1,3}/gi)

console.log(result);