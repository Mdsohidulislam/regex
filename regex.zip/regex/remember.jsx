// exec()	Executes a search for a match in a string. It returns an array of information or null on a mismatch.
// ////// exec baboharer niyom holo prothome regex nirnoy kora tarpor nirnoy krito regex dhara exec nirbachon kora




// test()	Tests for a match in a string. It returns true or false.


// match()	Returns an array containing all of the matches, including capturing groups, or null if no match is found.

// matchAll()	Returns an iterator containing all of the matches, including capturing groups.

// search()	Tests for a match in a string. It returns the index of the match, or -1 if the search fails.

// replace()	Executes a search for a match in a string, and replaces the matched substring with a replacement substring.

// replaceAll()	Executes a search for all matches in a string, and replaces the matched substrings with a replacement substring.

// split()	Uses a regular expression or a fixed string to break a string into an array of substrings.


/// \w word character
/// \d select ditig
/// \s space select
/// \W word character chara onno sob kichu
/// \D DIGIT chara onno sob kichu
/// \S white space chara onno sob kichu
/// \t tab select
/// \n new line select
/// . any character number, digit , word, new line bade // . charater also called period
/// third brackets select character [a-z] a theke z porjonto character select korbe ///[abck]/gi abck character select korbe globally and case insensitively [a-dA-De-jE-Jm-zM-z]
/// negation [^abc] abc chara sokol character select korbe [^a-g]
/// /colou?r/gi dhara bojhai u ekbar thankbe othoba thakbe na ? ei symble er mane holo zero othoba ekbar

/// /colou?r*/gi * mane holo zero othoba multiple occurrance expamle colo selected
/// /colou?r+/gi * mane holo one othoba multiple occurrance expamle colo unselected
/// /colou?r{2}/gi mane holo r dhuibar ache emkon word select korbe colourr / colorr selected color/colour/colorrr/colourrr unselected 
/// /colou?r{1,3}/gi mane holo r minimum 1 ti nibe abong maximum 3 bar nibe
/// \? is used to escape special character karon ? holo regex er expression key select color? example /colou?r\?/gi
/// /^My/gi My dhara jodi kono string suru hoi (start position match)
/// /he he$/gi $ dhara bojhai he he$ dhara string sesh hoyeche (end position match)
/// /^[0,9]/gi dhara bojai number diye suru hoyeche naki
/// /!$/gi ! dhara string sesh hoyeche naki
///
///
///
///